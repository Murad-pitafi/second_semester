import java.util.ArrayList;
import java.util.Scanner;

class Employee {
    private static int ID;
    private String Qualification;
    private String name;
    public ArrayList<String> skills = new ArrayList<String>();

    public ArrayList<String> getSkills() {
        return skills;
    }

    public void setSkills(ArrayList<String> skills) {
        this.skills = skills;
    }

    public String getName() {
        return name;
    }
    Scanner sc = new Scanner(System.in);
    public void setName(String name) {
        this.name = name;
    }

    public static int getID() {
        return ID;
    }

    public static void GenerateId(int ID) {
        Employee.ID = ID;
    }

    public String getQualification() {
        return Qualification;
    }

    public void setQualification(String qualification) {
        Qualification = qualification;
    }


    Employee() {
        System.out.println("i will initialize all values by null");
    }

     Employee(String qualification,  String name) {
        Qualification = qualification;

        this.name = name;
    }

    public void skillsCheck()
    {
        System.out.println("finding desired candidate for React Team");

    }
    public void display()
    {
        System.out.println("name " + getName());
        System.out.println(" id " + getID());
        System.out.println(" skills " + skills);
        System.out.println(" qualification " + getQualification());
    }
}
class MonthlySalariedEmployee extends Employee
{
    double BasicPay, Allowances;

    public MonthlySalariedEmployee( ) {

    }
    MonthlySalariedEmployee(double BasicPay, double Allowances)
    {
        super( "ME","Murad" );
        this.Allowances = Allowances;
        this.BasicPay = BasicPay;

    }

    public void skillsCheck()
    {
        if (skills.contains("react"))
        {
            System.out.println("employee meets requirment");
            BasicPay = 22000;
            Allowances = 10000;

                System.out.println("name " + getName());
                System.out.println(" id " + getID());
                System.out.println(" skills " + skills);
                System.out.println(" qualification " + getQualification());
                System.out.println(" salary  " + BasicPay );
                System.out.println(" Allowances " + Allowances);
            }
        }
    }
class HourlySalariedEmployee extends Employee
{
    private int HoursWorked, perHourSalary;

    HourlySalariedEmployee(){
    }

    HourlySalariedEmployee( int hoursWorked, int perHourSalary) {

        this.HoursWorked  = hoursWorked;
        this.perHourSalary = perHourSalary;
        setQualification("Me");
        setName("ayesha");
    }



    public int getHoursWorked() {
        return HoursWorked;
    }

    public void setHoursWorked(int hoursWorked) {
        HoursWorked = hoursWorked;
    }

    public int getPerHourSalary() {
        return perHourSalary;
    }

    public void setPerHourSalary(int perHourSalary) {
        this.perHourSalary = perHourSalary;
    }
    boolean selection = false;
    @Override
    public void skillsCheck() {
        super.skillsCheck();
        if (skills.contains("react") && HoursWorked == 4)
        {
            System.out.println(" you are selected");
             selection = true;
            System.out.println("name " + getName());
            System.out.println(" id " + getID());
            System.out.println(" skills " + skills);
            System.out.println(" qualification " + getQualification());
            System.out.println("Hours work " + HoursWorked);
            System.out.println("salary " + perHourSalary);
        }
    }


}
public class OOPLAB_MID_TASK {
    public static void main(String[] args) {


        System.out.println("Monthly Salaried employee");
        MonthlySalariedEmployee obj = new MonthlySalariedEmployee(453444, 1000);
        MonthlySalariedEmployee obj1 = new MonthlySalariedEmployee();
        obj.GenerateId(6);
        obj.skills.add("react");
        obj.skills.add("python");
        obj.skillsCheck();
        System.out.println("");
        System.out.println("Hourly Salaried employee");
        HourlySalariedEmployee obj3 = new HourlySalariedEmployee(4, 5643);
        HourlySalariedEmployee obj4 = new HourlySalariedEmployee();
        obj3.GenerateId(3);
        obj3.skills.add("react");
        obj3.skills.add("python");
        obj3.skillsCheck();
    }
}
