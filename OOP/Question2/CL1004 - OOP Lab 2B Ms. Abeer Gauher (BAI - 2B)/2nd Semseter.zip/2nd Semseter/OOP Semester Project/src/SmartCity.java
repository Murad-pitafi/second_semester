import java.io.*;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

interface Administration
{
     String CityName = "Karachi";
     void setName(String name);
     void setId(String id);
    String getName();
    String getId();
}
interface access extends Administration{
    public void login();
    public void register();
}
class EmployeeAuthentication  implements access
{
    private String empName;
    private String empId;
    static boolean t = false;
    Scanner sc = new Scanner(System.in);
    @Override
    public void setName(String name) {
        this.empName = name;
    }
    @Override
    public void setId(String id) {
        this.empId = id;
    }
    @Override
    public String getName() {
        return empName;
    }
    @Override
    public String getId() {
        return empId;
    }

    public void register() {
    try {
        FileWriter fw = new FileWriter("Registration.txt", true);
        System.out.println("signup ");
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter User Name: ");
        setName(sc.nextLine());
        if (getName() == null)
        {
            System.out.println("sorry your name should not be empty");
            this.register();
        }
        System.out.println("Enter Password: ");
        setId(sc.nextLine());
        String x = getName() + " " + getId();
        //fw.write("\n" + x);
        PrintWriter print = new PrintWriter(fw);
        print.println(x);
        fw.close();
        print.close();
    }catch(IOException e)
    {
        e.printStackTrace();
    }
    catch (InputMismatchException e )
    {
        System.out.println(e);
        this.register();
    }
    }
    public void login()
    {
        try {
            File file = new File("Registration.txt");
            System.out.println("login");
            System.out.println("enter name ");
            String name = sc.nextLine();
            if (name == null) {
                System.out.println("your name can't be empty fill details properly ");
                this.login();
            }
            System.out.println("enter password");
            String pass = sc.nextLine();
            String a = name + " " + pass;
            Scanner d = new Scanner(file);
            while(d.hasNext())
            {
                String x = d.nextLine();
                if (a.equals(x))
                {
                    System.out.println("logged");
                    t = true;
                    break;
                }


            }
            if(t == false)
            {
                System.out.println("please try again");
                this.login();
            }
        }catch(IOException e)
        {
            e.printStackTrace();
        }
        catch (InputMismatchException e )
        {
            System.out.println(e);
            this.login();
        }
  }
}
class UserAuthentication implements access {
    static boolean t = false;
    private String userName;
    private String userId;
    Scanner sc = new Scanner(System.in);
    @Override
    public void setName(String name) {
        this.userName = name;
    }
    @Override
    public void setId(String id) {
        this.userId = id;
    }

    @Override
    public String getName() {
        return userName;
    }

    @Override
    public String getId() {
        return userId;
    }

    public void register() {
        try {
            FileWriter fw = new FileWriter("URegistration.txt", true);
            System.out.println("signup ");
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter User Name: ");
            setName(sc.nextLine());
            if (getName() == null) {
                System.out.println("your name can't be empty please fill your detail correctly");
                this.register();
            }
            System.out.println("Enter Password: ");
            setId(sc.nextLine());
            String x = getName() + " " + getId();
            fw.write(x + "\n");
            fw.close();
        }catch(IOException e)
        {
            e.printStackTrace();
        }
        catch (InputMismatchException e )
        {
            System.out.println(e);
            this.register();
        }
        }
    public void login() {
        try {
        Scanner sc = new Scanner(System.in);
        File file = new File("URegistration.txt");
        System.out.println("login");
        System.out.println("enter name ");
        String name = sc.nextLine();
        if (name == null)
        {
            System.out.println("your name can't be empty");
            System.out.println("enter your name ");
            this.login();
        }
        System.out.println("enter password");
        String pass = sc.nextLine();
        String a = name + " " + pass;
        Scanner d = new Scanner(file);
        while(d.hasNext())
        {
            String x = d.nextLine();
            if (a.equals(x))
            {
                System.out.println("logged");
                t = true;
                break;
            }

        }
        if(t == false)
            {
                System.out.println("please login again");
                this.login();
            }
    }catch(IOException e) {
            e.printStackTrace();
        }
        catch (InputMismatchException e )
        {
            System.out.println(e);
           this.login();
        }
    }
}
abstract class smart_city {
    abstract void setPlace(String placeName);
    abstract String getPlace();
    abstract void setAddress(String address);
    abstract String getAddress();
    abstract void setContact(int contact);
    abstract int getContact();
    abstract void fillDetails();
    abstract void getDetails();
    abstract void searchDetails();
}
class tourism  extends smart_city {                          //class tourism
    private String Tplacename;
    private String Taddress;
    private int Tcontact;
    @Override
    public void setPlace(String placeName) {
        this.Tplacename = placeName;
    }
    @Override
    public String getPlace() {
     return    Tplacename;
    }
    @Override
    public void setAddress(String address) {
        this.Taddress = address;
    }
    @Override
    public String getAddress() {
        return Taddress;
    }
    @Override
    public void setContact(int contact) {
            this.Tcontact = contact;
    }
    @Override
    public int getContact() {
        return Tcontact;
    }
    Scanner sc = new Scanner(System.in);
    int n;
    public void fillDetails() {
            n++;
        try {
            System.out.println("enter place name");
            setPlace(sc.next());
            System.out.println("enter address");
            setAddress(sc.next());
            System.out.println("enter contact");
            setContact(sc.nextInt());
            String x = getPlace() + " " + getPlace() + " " + getContact();

                FileWriter fw = new FileWriter("Tourism.txt", true);
                fw.write(x + "\n");
                fw.close();
            }catch (IOException e)
            {
                e.printStackTrace();
            }
            catch (InputMismatchException e)
            {
                System.out.println(e);
                fillDetails();
            }
    }
    public void getDetails()
    {
        n=0;
        System.out.println(" PlaceName  Address  Contact");
        try {
            File file = new File("Tourism.txt");
            Scanner sc = new Scanner(file);
            while (sc.hasNext())
            {
                String d = sc.nextLine();
                System.out.print(d + " \n");
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void searchDetails() {
        try {
            File file = new File("Tourism.txt");
            System.out.println("Enter place name ");
            String pName = sc.next();
            Scanner d = new Scanner(file);
            while (d.hasNext()) {
                String x = d.next();
                //System.out.println(x);
                if (pName.equals(x))
                {
                    x = pName + d.nextLine();
                    System.out.println(x);
                    System.out.println("check");
                }
            }
        }catch(IOException e)
        {
            e.printStackTrace();
        }
        catch (InputMismatchException e )
        {
            e.printStackTrace();
        }
    }
}
class jobseekers extends smart_city {           //class jobseekers
    private String JplaceName;
    private String Jaddress;
    private int Jcontact;
    @Override
    public void setPlace(String placeName) {
        this.JplaceName = placeName;
    }
    @Override
    public String getPlace() {
        return JplaceName;
    }
    @Override
    public void setAddress(String address) {
        this.Jaddress = address;
    }
    @Override
    public String getAddress() {
        return Jaddress;
    }

    @Override
    public void setContact(int contact) {
        this.Jcontact = contact;
    }

    @Override
    public int getContact() {
        return Jcontact;
    }
    Scanner sc = new Scanner(System.in);
    int n;
    public void fillDetails()
    {
n++;
        try {
            System.out.println("enter place name");
            setPlace(sc.next());
            System.out.println("enter address");
            setAddress(sc.next());
            System.out.println("enter contact");
            setContact(sc.nextInt());
        }catch (InputMismatchException e)
        {
            this.fillDetails();
        }
        String x = getPlace() + " " + getAddress() + " " + getContact();
        try {
            FileWriter fw = new FileWriter("Jobseekers.txt", true);
            PrintWriter pw = new PrintWriter(fw);
            pw.println(x);
            fw.close();
        }catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (InputMismatchException e)
        {
            System.out.println(e);
            fillDetails();
        }
    }
    public void getDetails() {
        n = 0;
        System.out.println(" PlaceName  Address  Contact");
        try {
            File file = new File("Jobseekers.txt");
            Scanner sc = new Scanner(file);
            while (sc.hasNext()) {
                String d = sc.nextLine();
                System.out.print(d + " \n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        public void searchDetails() {
        try {
            File file = new File("Jobseekers.txt");
            System.out.println("Enter place name ");
            String pName = sc.nextLine();
            Scanner d = new Scanner(file);
            while (d.hasNext()) {
                String x = d.next();
                //System.out.println(x);
                if (pName.equals(x))
                {
                    x = pName + d.nextLine();
                    System.out.println(x);
                    //System.out.println("searching");
                }
            }
        }catch(IOException e)
        {
            e.printStackTrace();
        }catch (InputMismatchException e)
        {
            System.out.println("please use only first word");
            this.searchDetails();
        }
    }
}
class business extends smart_city {              //class business

    private String Bplacename;
    private String Baddress;
    private int Bcontact;

    @Override
    public void setPlace(String placeName) {
        this.Bplacename = placeName;
    }

    @Override
    public String getPlace() {
        return Bplacename;
    }

    @Override
    public void setAddress(String address) {
        this.Baddress = address;
    }

    @Override
    public String getAddress() {
        return Baddress;
    }

    @Override
    public void setContact(int contact) {
        this.Bcontact = contact;
    }

    @Override
    public int getContact() {
        return Bcontact;
    }

    Scanner sc = new Scanner(System.in);
    int n;
    public void fillDetails() {
        n++;
        try {
        System.out.println("enter place name");
        setPlace(sc.next());
        System.out.println("enter address");
        setAddress(sc.next());
        System.out.println("enter contact");
        setContact(sc.nextInt());
        String x = getPlace() + " " + getPlace() + " " + getContact();

            FileWriter fw = new FileWriter("Business.txt", true);
            fw.write(x + "\n");
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InputMismatchException e) {
            System.out.println(e);
            fillDetails();
        }
    }

    public void getDetails() {
         n= 0;

        System.out.println(" PlaceName  Address  Contact");
        try {
            File file = new File("Business.txt");
            Scanner sc = new Scanner(file);
            while (sc.hasNext()) {
                String d = sc.nextLine();
                System.out.print(d + " \n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void searchDetails() {
        try {
            File file = new File("Business.txt");
            System.out.println("Enter place name ");
            String pName = sc.next();
            Scanner d = new Scanner(file);
            while (d.hasNext()) {
                String x = d.next();
                //System.out.println(x);
                if (pName.equals(x)) {
                    x = pName + d.nextLine();
                    System.out.println(x);
                    System.out.println("check");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }catch (InputMismatchException e)
        {
            this.searchDetails();
        }
    }
}
class Education extends smart_city {         //class student

    private String SplaceName;
    private String Saddress;
    private int Scontact;

    @Override
    public void setPlace(String placeName) {
        this.SplaceName = placeName;
    }

    @Override
    public String getPlace() {
        return SplaceName;
    }

    @Override
    public void setAddress(String address) {
        this.Saddress = address;
    }

    @Override
    public String getAddress() {
        return Saddress;
    }

    @Override
    public void setContact(int contact) {
        this.Scontact = contact;
    }

    @Override
    public int getContact() {
        return Scontact;
    }

    Scanner sc = new Scanner(System.in);
        int n;
    public void fillDetails() {
        try {
        n++;
        System.out.println("enter place name");
        setPlace(sc.next());
        System.out.println("enter address");
        setAddress(sc.next());
        System.out.println("enter contact");
        setContact(sc.nextInt());
        String x = getPlace() + " " + getPlace() + " " + getContact();

            FileWriter fw = new FileWriter("Education.txt", true);
            fw.write(x + "\n");
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InputMismatchException e) {
            System.out.println(e);
            fillDetails();
        }
    }

    public void getDetails() {
        System.out.println(" PlaceName  Address  Contact");
        try {
            n = 0;
            File file = new File("Education.txt");
            Scanner sc = new Scanner(file);
            while (sc.hasNext()) {
                String d = sc.nextLine();
                System.out.print(d + " \n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void searchDetails() {
        try {

            File file = new File("Education.txt");
            System.out.println("Enter place name ");
            String pName = sc.next();
            Scanner d = new Scanner(file);
            while (d.hasNext()) {
                String x = d.next();
                //System.out.println(x);
                if (pName.equals(x)) {
                    x = pName + d.nextLine();
                    System.out.println(x);
                    System.out.println("check");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }catch (InputMismatchException e)
        {
            this.searchDetails();
        }
    }
}
public class SmartCity {
        public static void home()
        {
            Scanner sc = new Scanner(System.in);
            int opt;
            int domain;
            tourism tr = new tourism();
            Education ed = new Education();
            jobseekers job = new jobseekers();
            business bus = new business();
            do {
                System.out.println("Welcome to SMART CITY ");
                System.out.println("1 Administration\n 2 Vistor ");
                System.out.println("3 Exit");
                opt = sc.nextInt();
                System.out.print("\033[H\033[2J");
                switch (opt) {
                    case 1 -> {
                        EmployeeAuthentication emp = new EmployeeAuthentication();
                        int b;
                        do
                        {
                            System.out.println(" 1-> Signup");
                            System.out.println(" 2-> Login");
                            System.out.println(" 3-> back");
                         b = sc.nextInt();
                            switch (b) {
                                case 1 -> {
                                    System.out.println(" Employee Registration");
                                    emp.register();
                                }
                                case 2 -> {
                                    System.out.println(" Employee Login");
                                    emp.login();
                                }
                            }
                            if (EmployeeAuthentication.t == true) {
                                    do {
                                        System.out.println("Fill  details");
                                        System.out.println("please select your domain ");
                                        System.out.println("1-> business");
                                        System.out.println("2-> Jobs");
                                        System.out.println("3-> Tourism");
                                        System.out.println("4-> Education");
                                        System.out.println("5-> back");
                                        domain = sc.nextInt();
                                        switch (domain) {
                                            case 1 -> {
                                                System.out.println("places for business ");
                                                bus.fillDetails();
                                            }
                                            case 2 -> {
                                                System.out.println("places for jobs ");
                                                job.fillDetails();
                                            }
                                            case 3 -> {
                                                System.out.println("places for tourism ");
                                                tr.fillDetails();
                                            }
                                            case 4 -> {
                                                System.out.println("places for Education ");
                                                ed.fillDetails();
                                            }

                                        }
                                    } while (domain != 5);
                                    EmployeeAuthentication.t = false;
                            }
                        }while(b != 3);
                    }
                    case 2 -> {
                        UserAuthentication obj = new UserAuthentication();
                        int f;
                        do
                        {
                            System.out.println(" 1-> Signup");
                            System.out.println(" 2-> Login");
                            System.out.println(" 3-> back");
                            f = sc.nextInt();
                            switch (f) {

                                case 1 -> {
                                    System.out.println("user register ");
                                    obj.register();
                                }
                                case 2 -> {
                                    System.out.println("user login"); obj.login();}


                            }
                            if (UserAuthentication.t == true) {
                                do {
                                    System.out.println("see details");
                                    System.out.println("please select your domain ");
                                    System.out.println("1-> business " + "(" + bus.n + ")");
                                    System.out.println("2-> Jobs " + "(" +job.n + ")");
                                    System.out.println("3-> Tourism" + "(" + tr.n + ")");
                                    System.out.println("4-> Education" + "(" + ed.n + ")");
                                    System.out.println("5-> back");
                                    domain = sc.nextInt();
                                    switch (domain) {
                                        case 1 -> {
                                            System.out.println("places for business ");
                                           bus.getDetails();
                                            bus.searchDetails();
                                            System.out.println("press 1 if you want to search ");
                                            int s = sc.nextInt();
                                            if(s==1)
                                            {
                                                bus.searchDetails();
                                            }
                                        }
                                        case 2 -> {
                                            System.out.println("places for jobs ");
                                            job.getDetails();
                                            System.out.println("press 1 if you want to search ");
                                            int s = sc.nextInt();
                                            if(s==1)
                                            {
                                                job.searchDetails();
                                            }


                                        }
                                        case 3 -> {
                                            System.out.println("places for tourism ");
                                            tr.getDetails();
                                            System.out.println("press 1 if you want to search ");
                                            int s = sc.nextInt();
                                            if(s==1)
                                            {
                                                tr.searchDetails();
                                            }

                                        }
                                        case 4 -> {
                                            System.out.println("places for Education ");
                                                ed.getDetails();
                                            System.out.println("press 1 if you want to search ");
                                            int s = sc.nextInt();
                                            if(s==1)
                                            {
                                                ed.searchDetails();
                                            }

                                        }
                                    }
                                }while(domain != 5);
                            }
                            UserAuthentication.t = false;
                        }while(f != 3);
                    }
                }
            }while (opt != 3) ;
        }
    public static void main(String[] args)  {
        home();
        }
    }